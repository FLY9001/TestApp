﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Wexin.Controllers
{
    public class WexinController : Controller
    {
        // GET: Wexin
        public ActionResult Index()
        {
            return View();
        }
    }
}