﻿function AddParent() {
    var html = "";
    html += "<div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>宝贝名</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝姓名' />";
    html += "</div></div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>性别</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝性别' />";
    html += "</div></div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>身份证号</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝身份证号' />";
    html += "</div></div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>所在学校</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝所在学校' />";
    html += "</div></div></div>";
    html += "<a href='javascript: ;' class='weui-btn weui-btn_mini weui-btn_warn' onclick=’DelBaBy()'>删除该信息</a>";    
    $("#parent").append(html);        
}

function AddKids() {
    var html = "";
    html += "<div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>宝贝名</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝姓名' />";    
    html += "</div></div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>性别</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝性别' />";
    html += "</div></div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>身份证号</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝身份证号' />";
    html += "</div></div>";
    html += "<div class='weui-cell'>";
    html += " <div class='weui-cell__hd'><label class='weui-label'>所在学校</label></div>";
    html += "<div class='weui-cell__bd'>";
    html += "<input class='weui-input' type='text' placeholder='请输入宝贝所在学校' />";    
    html += "</div></div></div>";    
    html += "<a href='javascript: ;' class='weui-btn weui-btn_mini weui-btn_warn' onclick=’DelBaBy()'>删除该信息</a>";    
    $("#baby").append(html);       
}

function DelBaBy() {

}
function DelParent() {

}